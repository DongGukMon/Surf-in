import React, { createContext } from 'react';

export const qrContext = createContext();

