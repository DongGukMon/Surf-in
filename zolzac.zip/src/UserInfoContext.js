import { createContext } from 'react';

export const UserInfoContext = createContext();
